import java.io.*;

public class Program5 {
	public static void main(String[] args) {
		File files = new File("/Users/Parth/OneDrive/Desktop/PRACTICE/Program4.java");

		System.out.println(files.getName() + " " + files.length() + " bytes " );
	}
}