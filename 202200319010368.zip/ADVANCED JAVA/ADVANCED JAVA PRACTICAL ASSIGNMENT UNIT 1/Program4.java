import java.io.*;

public class Program4 {
	public static void main(String[] args) {
		File file = new File ("/Users/Parth/OneDrive/Desktop/PRACTICE/Program3.java");

		System.out.println("The size of the file is " + file.length());
	}
}